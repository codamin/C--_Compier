package main.symbolTable.exceptions;


public class ItemNotFoundException extends Exception {
}
