package main.ast.types.primitives;

import main.ast.types.Type;

public class IntType extends Type {
    @Override
    public String toString() {
        return "IntType";
    }
}
