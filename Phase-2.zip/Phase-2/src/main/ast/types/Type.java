package main.ast.types;

public abstract class Type {
    public abstract String toString();
}
